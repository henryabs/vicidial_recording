<?php
	$base_url = getcwd();
	include_once($base_url.'/core/sulot.php');
	include_once($base_url.'/config/db.php');
	include_once($base_url.'/config/campaign.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <title>Bima Recordings</title>
  </head>
  <body>
    <div class="container">
    	<br />
    	<div class="row">

    		<div class="col-md-3"></div>
    		<div class="col-md-6">
    			<div class="alert alert-success" role="alert" style="border: 3px solid black">
				  <a href="./">
				  <img src="../bima/asset/logo.png" height="80px">
				  </a>
				  <hr>
				  <form action="" method="POST">
				  		<div class="form-group">
						    <b><label for="Agents">Select Agent Here</label></b>
						    <select class="form-control" id="Agents" name="agent">
							   <option>Choose Agent...</option>
								<?php
								//Select all agents of Bima
								$select_agent = $conn->prepare("SELECT `user`,`full_name` FROM `vicidial_users` WHERE `user_group` = :user_group ORDER BY `user` ASC");
								$select_agent->bindParam(':user_group',$userGroup);
								$select_agent->execute();
								$count = $select_agent->rowCount();
									if($count > 0)
									{

										while($user = $select_agent->fetch())
										{
											echo '<option>'.$user['user'].'</option>';
										}
									}
								?>
						    </select>
						 </div>

						 <div class="form-group">
						    <b><label for="From">From</label></b>
						    <input type="date" name="begin" class="form-control" value="<?php echo date('Y-m-d'); ?>">
						 </div>

						 <div class="form-group">
						    <b><label for="To">To</label></b>
						    <input type="date" name="end" class="form-control" value="<?php echo date('Y-m-d'); ?>">
						 </div>

						 <div class="form-group">
						    <input type="submit" name="search_rec" value="Download Records" class="btn btn-secondary active">
						 </div>

						 <?php
						 if(isset($_POST['search_rec']))
						 {
						 	
						 	$agent = $_POST['agent'];
							$begin_log = $_POST['begin'].' 0:00:01';
					        $end_log = $_POST['end'].' 23:59:59';
					        if($agent == 'Choose Agent...')
					        {
					        	echo '<span class="badge badge-danger">Please Choose your agent!</span>';
					        }else
					        {
					        	$select_rec = $conn->prepare("SELECT `location`,`filename` FROM `recording_log` WHERE `user`=:user AND `start_time` >= :begin_log AND `start_time` <= :end_log");
								$select_rec->bindParam(':user',$agent);
								$select_rec->bindParam(':begin_log',$begin_log);
								$select_rec->bindParam(':end_log',$end_log);
								$select_rec->execute();
								$rec_count = $select_rec->rowCount();
								if($rec_count > 0)
								{
									$time_start = microtime(true);
									if(substr($_POST['begin'],8) !== substr($_POST['end'],8))
									{
										$folder = $_POST['begin'].'_to_'.$_POST['end'];
									}else
									{
										$folder = $_POST['begin'];
									}

									if(!file_exists($DIR.$folder.'/'.$agent))
									{
										mkdir($DIR.$folder.'/'.$agent, 0777, true);

										while($loc = $select_rec->fetch())
										{
											$source = $loc['location'];
											$dest = $DIR.$folder.'/'.$agent.'/'.$loc['filename'].'.mp3';
											try
											{
												@copy($source,$dest);
											}
											catch(Exception $e)
											{
												echo $e->getMessage();
											}
										}
									}
									else
									{
										while($loc = $select_rec->fetch())
										{
											$source = $loc['location'];
											$dest = $DIR.$folder.'/'.$agent.'/'.$loc['filename'].'.mp3';
											try
											{
												@copy($source,$dest);
											}
											catch(Exception $e)
											{
												echo $e->getMessage();
											}
										}
									}
									$time_end = microtime(true);

									//dividing with 60 will give the execution time in minutes otherwise seconds
									$execution_time = ($time_end - $time_start)/60;
									
									echo '<span class="badge badge-primary">Recording for '.$agent.' has been save; Time: '.number_format((float) $execution_time, 10).'</span>';
								}else
								{
									echo '<span class="badge badge-danger">No recordings found for '.$agent.'</span>';
								}
					        }
					        
						 }
						 
						 ?>

				  </form>
				  <hr>
				  <div style="text-align: right;""><code style="text-align: right;color:#F9A521;">Copyright &copy 2019. ICCS</code></div>
				</div>
    		</div>
    		<div class="col-md-3"></div>
    	</div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>