<?php
//USERGROUP//
$userGroup = 'Bima';
//USERGROUP//

//DIRECTORY//
$DIR = 'C:/Users/IT/Desktop/BIMA_RECORDINDS/';
//DIRECTORY//
?>