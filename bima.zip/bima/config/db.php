<?php
//VICIDIAL DATABASE CREDENTIAL
class DB
{
	public function connect($host,$user,$pass,$db)
	{

		
		$connection = new PDO('mysql:host='.$host.';dbname='.$db.';charset=utf8;', $user, $pass);
		return $connection;
		
	}
}

/*Creating encrypted variable for database connection*/
$host = Sulot::_XYZ('qD+xAxFYaNcocAp/wRTwRw==');
$user = Sulot::_XYZ('9RcxQa2HriuueEU47curdw==');
$pass = Sulot::_XYZ('aGKsbVJMxB91p6ZUmPKJ8A==');
$db = Sulot::_XYZ('O21UxhuiBhFK2thpWbLi3g==');
try
{
	$conn = DB::connect($host,$user,$pass,$db);
}
catch(Exception $e)
{
	echo 'There is something wrong with the site! Please try again later';
}
/*Creating variable for database connection*/

//VICIDIAL DATABASE CREDENTIAL
?>